const { shuffle } = require('./utils')
class Deck {
  // prettier-ignore
  static cards = [
    "2c","3c","4c","5c","6c","7c","8c","9c","Tc","Jc","Qc","Kc","Ac",
    "2d","3d","4d","5d","6d","7d","8d","9d","Td","Jd","Qd","Kd","Ad",
    "2h","3h","4h","5h","6h","7h","8h","9h","Th","Jh","Qh","Kh","Ah",
    "2s","3s","4s","5s","6s","7s","8s","9s","Ts","Js","Qs","Ks","As",
];

  static shuffleDeck = (deck, times = 1) => {
    let shuffledDeck = [...deck]

    shuffledDeck = shuffle(shuffledDeck)
    if (times > 1) {
      for (let i = 0; i < times; i++) {
        shuffledDeck = shuffle(shuffledDeck)
      }
    }

    return shuffledDeck
  }

  static originalDeck = Deck.shuffleDeck(Deck.cards)
}

module.exports = Deck

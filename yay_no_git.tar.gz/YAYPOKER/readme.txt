docker compose up --build

IP: 162.222.205.171
User: root
Pass: IJzxVa4zo8L4


ssh root@162.222.205.171


TAR
tar --exclude='.git' --exclude='*/node_modules' --exclude='*/built' --exclude='*/dist' -czvf yay_no_git.tar.gz -C /home/osito/Development/GIT YAYPOKER

en la maquina local usar
scp -r /home/osito/Development/GIT/YAYPOKER/yay_no_git.tar.gz root@162.222.205.171:/root/yaypoker

UNTAR
tar -xzvf yay_no_git.tar.gz



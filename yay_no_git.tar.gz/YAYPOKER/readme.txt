docker compose up --build


IP: 162.222.205.171
User: root
Pass: IJzxVa4zo8L4


ssh root@162.222.205.171

1 - LOCAL - DENTRO DE YAYPOKER HACER TAR
tar --exclude='.git' --exclude='*/node_modules' --exclude='*/build' --exclude='*/dist' -czvf yay_no_git.tar.gz -C /home/osito/Development/GIT YAYPOKER

2 - en la maquina local usar
scp -r /home/osito/Development/GIT/YAYPOKER/yay_no_git.tar.gz root@162.222.205.171:/root

3 - REMOTO IR A RAIZ ROOT - UNTAR
tar -xzvf yay_no_git.tar.gz

REMOTO - cd YAYPOKER 
docker compose -f docker-compose-prod.yml down --rmi all -v && \
docker compose -f docker-compose-prod.yml up --build


PARA VER LOS LOGS
docker logs -f yaypoker-websocket-1 


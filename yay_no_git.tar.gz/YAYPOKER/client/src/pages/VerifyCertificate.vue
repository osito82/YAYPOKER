<template>
  <div
    class="verify-page min-h-screen bg-white dark:bg-neutral-950 flex items-center justify-center p-6 relative overflow-hidden font-sans transition-colors duration-300"
  >
    <!-- Decorative background -->
    <div class="absolute inset-0 pointer-events-none">
      <div
        class="absolute inset-0 bg-[radial-gradient(ellipse_70%_50%_at_50%_0%,rgba(212,168,83,0.05)_0%,transparent_60%)]"
      ></div>
      <div
        class="absolute inset-0 bg-[repeating-linear-gradient(45deg,transparent,transparent_2px,rgba(0,0,0,0.01)_2px,rgba(0,0,0,0.01)_4px)] dark:bg-[repeating-linear-gradient(45deg,transparent,transparent_2px,rgba(255,255,255,0.01)_2px,rgba(255,255,255,0.01)_4px)]"
      ></div>
    </div>

    <div
      class="page-content relative z-10 w-full max-w-[520px] flex flex-col items-center gap-6"
    >
      <!-- Header -->
      <header class="header text-center animate-fade-down">
        <span class="logo-mark text-[36px] mb-2 block">🃏</span>
        <p
          class="site-name font-mono text-[10px] tracking-[4px] text-yellow-700 dark:text-[#8A6A2A] uppercase mb-3"
        >
          {{ $t('pages.verify.site_name') }}
        </p>
        <h1
          class="page-title font-bebas text-[clamp(36px,8vw,52px)] tracking-[2px] bg-gradient-to-br from-yellow-600 via-yellow-500 to-yellow-700 dark:from-[#F5D78E] dark:to-[#D4A853] bg-clip-text text-transparent"
        >
          {{ $t('pages.verify.headline') }}
        </h1>
        <p
          class="page-sub text-[13px] text-gray-500 dark:text-[#7A7268] mt-1 leading-relaxed"
          v-html="$t('pages.verify.sub')"
        ></p>
      </header>

      <div class="divider w-10 h-px bg-yellow-500/30 mx-auto"></div>

      <!-- Input Card -->
      <div
        v-if="!result"
        class="input-card w-full bg-gray-50 dark:bg-[#142A16] border border-gray-200 dark:border-[#D4A853]/20 rounded-2xl p-7 animate-fade-up shadow-2xl transition-all duration-300"
      >
        <div class="field-group mb-5">
          <label
            class="field-label font-mono text-[9px] tracking-[3px] uppercase text-yellow-700 dark:text-[#D4A853] block mb-2"
            >{{ $t('pages.verify.torneo_id_label') }}</label
          >
          <input
            v-model="torneoId"
            class="field-input w-full bg-white dark:bg-black/40 border border-gray-200 dark:border-white/10 rounded-xl p-3 px-4 text-gray-900 dark:text-[#F5F0E8] font-mono text-sm outline-none transition-colors tracking-widest focus:border-yellow-500 dark:focus:border-[#D4A853]/50 focus:ring-4 focus:ring-yellow-500/5 dark:focus:ring-[#D4A853]/5"
            :placeholder="$t('pages.verify.torneo_id_placeholder')"
            autocomplete="off"
            spellcheck="false"
            :class="{ 'shake-animation border-red-500/70': errors.torneoId }"
          />
        </div>

        <div class="field-group mb-5">
          <label
            class="field-label font-mono text-[9px] tracking-[3px] uppercase text-yellow-700 dark:text-[#D4A853] block mb-2"
            >{{ $t('pages.verify.code_label') }}</label
          >
          <div class="code-input-row flex gap-2.5 items-center justify-center">
            <input
              v-for="(digit, i) in codeDigits"
              :key="i"
              :id="`digit-${i}`"
              ref="digitInputs"
              v-model="codeDigits[i]"
              type="text"
              inputmode="numeric"
              maxlength="1"
              class="digit-input w-16 h-20 bg-white dark:bg-black/50 border-2 border-gray-200 dark:border-white/10 rounded-xl text-center text-yellow-600 dark:text-[#F5D78E] font-bebas text-[42px] outline-none transition-all focus:border-yellow-500 dark:focus:border-[#D4A853] focus:ring-4 focus:ring-yellow-500/10 dark:focus:ring-[#D4A853]/10"
              :class="{
                'filled border-yellow-500/40 dark:border-[#D4A853]/40':
                  codeDigits[i],
                'shake-animation border-red-500/70': errors.code,
              }"
              @input="onInput($event, i)"
              @keydown="onKeyDown($event, i)"
              @paste="onPaste"
            />
          </div>
        </div>

        <button
          @click="verify"
          :disabled="isVerifying"
          class="verify-btn w-full p-4 bg-gradient-to-br from-yellow-500 to-yellow-700 dark:from-[#D4A853] dark:to-[#8A6A2A] border-none rounded-xl text-white dark:text-[#060E07] font-bebas text-[20px] tracking-[3px] cursor-pointer transition-all hover:-translate-y-0.5 hover:shadow-[0_8px_24px_rgba(212,168,83,0.3)] active:translate-y-0 disabled:opacity-40 disabled:cursor-not-allowed disabled:transform-none relative overflow-hidden group"
        >
          <span class="relative z-10">{{
            isVerifying
              ? $t('pages.verify.verifying')
              : $t('pages.verify.verify_btn')
          }}</span>
          <div
            class="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:animate-shimmer"
          ></div>
        </button>
      </div>

      <!-- Result Panel -->
      <div
        v-else
        class="result-panel w-full rounded-2xl p-6 px-7 animate-result-pop shadow-2xl transition-all duration-300"
        :class="
          result.valid
            ? 'valid bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-500/40'
            : 'invalid bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/30'
        "
      >
        <span class="result-icon text-4xl block mb-3">{{
          result.valid ? '✅' : '❌'
        }}</span>
        <p
          class="result-status font-bebas text-2xl tracking-widest mb-1"
          :class="
            result.valid
              ? 'text-emerald-600 dark:text-[#27AE60]'
              : 'text-red-600 dark:text-[#C0392B]'
          "
        >
          {{
            result.valid
              ? $t('pages.verify.valid_status')
              : $t('pages.verify.invalid_status')
          }}
        </p>
        <p
          class="result-msg text-[13px] text-gray-500 dark:text-[#7A7268] mb-4 leading-relaxed"
        >
          {{ result.valid ? $t('pages.verify.valid_msg') : result.error }}
        </p>

        <div
          v-if="result.valid && result.certificate"
          class="winner-detail bg-gray-100 dark:bg-black/30 border border-gray-200 dark:border-transparent rounded-xl p-4 grid grid-cols-2 gap-3 mb-4"
        >
          <div class="detail-item col-span-2">
            <p
              class="detail-label font-mono text-[8px] tracking-[2px] uppercase text-gray-500 dark:text-[#7A7268] mb-0.5"
            >
              {{ $t('pages.verify.winner_label') }}
            </p>
            <p
              class="detail-value name font-bebas text-2xl text-yellow-700 dark:text-[#F5D78E] tracking-wider"
            >
              {{ result.certificate.winnerName.toUpperCase() }}
            </p>
          </div>
          <div class="detail-item">
            <p
              class="detail-label font-mono text-[8px] tracking-[2px] uppercase text-gray-500 dark:text-[#7A7268] mb-0.5"
            >
              {{ $t('pages.verify.torneo_id_display') }}
            </p>
            <p
              class="detail-value font-mono text-[13px] text-gray-900 dark:text-[#F5F0E8] font-medium"
            >
              {{ result.certificate.torneoId }}
            </p>
          </div>
          <div class="detail-item">
            <p
              class="detail-label font-mono text-[8px] tracking-[2px] uppercase text-gray-500 dark:text-[#7A7268] mb-0.5"
            >
              {{ $t('pages.verify.date_label') }}
            </p>
            <p
              class="detail-value font-mono text-[13px] text-gray-900 dark:text-[#F5F0E8] font-medium"
            >
              {{ formatDate(result.certificate.date) }}
            </p>
          </div>
          <div class="detail-item">
            <p
              class="detail-label font-mono text-[8px] tracking-[2px] uppercase text-gray-500 dark:text-[#7A7268] mb-0.5"
            >
              {{ $t('pages.verify.players_label') }}
            </p>
            <p
              class="detail-value font-mono text-[13px] text-gray-900 dark:text-[#F5F0E8] font-medium"
            >
              {{
                $t('pages.verify.players_count', {
                  count: result.certificate.totalPlayers,
                })
              }}
            </p>
          </div>
          <div class="detail-item">
            <p
              class="detail-label font-mono text-[8px] tracking-[2px] uppercase text-gray-500 dark:text-[#7A7268] mb-0.5"
            >
              {{ $t('pages.verify.chips_label') }}
            </p>
            <p
              class="detail-value font-mono text-[13px] text-gray-900 dark:text-[#F5F0E8] font-medium"
            >
              {{
                $t('pages.verify.chips_count', {
                  count: result.certificate.chipsWon.toLocaleString(),
                })
              }}
            </p>
          </div>
        </div>

        <div
          v-if="result.valid"
          class="seal inline-flex items-center gap-2 px-3 py-1.5 bg-emerald-100 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-500/30 rounded-full font-mono text-[10px] tracking-[2px] text-emerald-700 dark:text-[#27AE60]"
        >
          <div
            class="seal-dot w-1.5 h-1.5 bg-emerald-600 dark:bg-[#27AE60] rounded-full"
          ></div>
          {{ $t('pages.verify.verified_by') }}
        </div>

        <button
          @click="reset"
          class="try-again mt-6 bg-transparent border border-gray-300 dark:border-white/15 rounded-lg text-gray-500 dark:text-[#7A7268] font-mono text-[10px] tracking-[2px] p-2 px-4 cursor-pointer transition-colors hover:border-gray-400 dark:hover:border-white/30 hover:text-gray-700 dark:hover:text-[#F5F0E8]"
        >
          {{ $t('pages.verify.verify_another') }}
        </button>
      </div>

      <footer
        class="footer font-mono text-[9px] tracking-[2px] text-yellow-800/50 dark:text-[#8A6A2A]/50 text-center"
      >
        {{ $t('pages.verify.footer') }}
      </footer>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, nextTick } from 'vue'
import { useRoute } from 'vue-router'
import { urlsFactory } from '../vutils'

const route = useRoute()
const urls = urlsFactory()

const torneoId = ref('')
const codeDigits = ref(['', '', '', ''])
const digitInputs = ref([])
const isVerifying = ref(false)
const result = ref(null)
const errors = ref({ torneoId: false, code: false })

onMounted(() => {
  if (route.params.torneoId) {
    torneoId.value = route.params.torneoId
  }
  if (route.params.code) {
    const code = route.params.code.toString().padStart(4, '0')
    const digits = code.split('').slice(0, 4)
    for (let i = 0; i < 4; i++) {
      codeDigits.value[i] = digits[i] || ''
    }
    nextTick(() => {
      verify()
    })
  }
})

const onInput = (e, i) => {
  const val = e.target.value.replace(/\D/g, '')
  codeDigits.value[i] = val
  if (val && i < 3) {
    digitInputs.value[i + 1].focus()
  }
}

const onKeyDown = (e, i) => {
  if (e.key === 'Backspace' && !codeDigits.value[i] && i > 0) {
    digitInputs.value[i - 1].focus()
    codeDigits.value[i - 1] = ''
  }
  if (e.key === 'Enter') {
    verify()
  }
}

const onPaste = (e) => {
  e.preventDefault()
  const pasted = (e.clipboardData.getData('text') || '')
    .replace(/\D/g, '')
    .slice(0, 4)
  const digits = pasted.split('')
  for (let j = 0; j < 4; j++) {
    codeDigits.value[j] = digits[j] || ''
  }
  if (pasted.length === 4) {
    verify()
  }
}

const verify = async () => {
  if (isVerifying.value) return

  errors.value.torneoId = !torneoId.value.trim()
  const fullCode = codeDigits.value.join('')
  errors.value.code = fullCode.length < 4

  if (errors.value.torneoId || errors.value.code) {
    setTimeout(() => {
      errors.value.torneoId = false
      errors.value.code = false
    }, 500)
    return
  }

  isVerifying.value = true
  try {
    const res = await fetch(
      `${urls.serverHttp}/verify/${torneoId.value}/${fullCode}`,
    )
    if (!res.ok) throw new Error('Error de servidor')
    result.value = await res.json()
  } catch (err) {
    result.value = { valid: false, error: 'Error de conexión con el servidor.' }
  } finally {
    isVerifying.value = false
  }
}

const reset = () => {
  result.value = null
  codeDigits.value = ['', '', '', '']
  torneoId.value = ''
}

const formatDate = (dateStr) => {
  return new Date(dateStr).toLocaleDateString('es-ES', {
    day: '2-digit',
    month: 'long',
    year: 'numeric',
  })
}
</script>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Mono:wght@400;500&family=DM+Sans:wght@300;400;500&display=swap');

.font-bebas {
  font-family: 'Bebas Neue', sans-serif;
}
.font-mono {
  font-family: 'DM Mono', monospace;
}
.font-sans {
  font-family: 'DM Sans', sans-serif;
}

.animate-fade-down {
  animation: fade-down 0.5s both;
}
.animate-fade-up {
  animation: fade-up 0.5s 0.1s both;
}
.animate-result-pop {
  animation: result-pop 0.4s cubic-bezier(0.34, 1.56, 0.64, 1) both;
}

@keyframes fade-down {
  from {
    opacity: 0;
    transform: translateY(-16px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
@keyframes fade-up {
  from {
    opacity: 0;
    transform: translateY(16px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
@keyframes result-pop {
  from {
    transform: scale(0.9);
    opacity: 0;
  }
  to {
    transform: scale(1);
    opacity: 1;
  }
}
@keyframes shimmer {
  to {
    transform: translateX(100%);
  }
}
@keyframes shake {
  0%,
  100% {
    transform: translateX(0);
  }
  20% {
    transform: translateX(-6px);
  }
  40% {
    transform: translateX(6px);
  }
  60% {
    transform: translateX(-4px);
  }
  80% {
    transform: translateX(4px);
  }
}

.shake-animation {
  animation: shake 0.35s ease;
}

.custom-scrollbar::-webkit-scrollbar {
  width: 4px;
}
.custom-scrollbar::-webkit-scrollbar-thumb {
  background: rgba(212, 168, 83, 0.2);
  border-radius: 10px;
}
</style>
